document.addEventListener('DOMContentLoaded', () => {
    let up = document.getElementById("up");
    let whatsapp = document.getElementById("whatsapp");
    let bars = document.getElementById("bars");
    let mainheader = document.getElementById("mainheader");
    let body = document.querySelector("body");
    // menu 
    if (window.screen.width < 768) {
        const googleSvgLeftArrow = `
        <svg 
            xmlns="http://www.w3.org/2000/svg" 
            height="24" 
            viewBox="0 0 24 24" 
            width="24" 
            fill="currentColor"
        >
            <path d="M0 0h24v24H0V0z" fill="none"/>
            <path d="M15.41 16.59L10.83 12l4.58-4.59L14 6l-6 6 6 6 1.41-1.41z"/>
        </svg>
    `;
        const menuItems = document.querySelectorAll('.menu-item-has-children');

        menuItems.forEach(item => {
            const arrowBox = document.createElement('span');
            arrowBox.classList.add('bg-primary','rounded-xl','p-4');
            arrowBox.innerHTML = googleSvgLeftArrow;

            // Appends the arrow box to the end of the item (right side)
            item.append(arrowBox);

            // Adds flex and justify-between for spacing
            item.classList.add("w-full","flex", "justify-between");
            arrowBox.addEventListener("click",()=>{
                item.classList.add("active");
            })
        });
    }

    // swipers
    var swiper = new Swiper(".mySwipera", {
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        pagination: {
            el: ".swiper-pagination",
        },
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
    });
    var swiper = new Swiper(".mySwiperb", {
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        pagination: {
            el: ".swiper-pagination",
        },
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
    });
    var swiper = new Swiper(".mySwiperc", {
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        pagination: {
            el: ".swiper-pagination",
        },
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
    });
    var swiper = new Swiper(".shegeftSwiper", {
        slidesPerView: 1,
        spaceBetween: 5,
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        breakpoints: {
            640: {
                slidesPerView: 2,
                spaceBetween: 10,
            },
            768: {
                slidesPerView: 3,
                spaceBetween: 15,
            },
            1024: {
                slidesPerView: 4,
                spaceBetween: 20,
            },
        },
    });
    var swiper = new Swiper(".sellerSwiper", {
        slidesPerView: 1,
        spaceBetween: 5,
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        breakpoints: {
            640: {
                slidesPerView: 2,
                spaceBetween: 10,
            },
            768: {
                slidesPerView: 3,
                spaceBetween: 15,
            },
            1024: {
                slidesPerView: 4,
                spaceBetween: 20,
            },
        },
    });
    var swiper = new Swiper(".brandsSwiper", {
        slidesPerView: 1,
        spaceBetween: 5,
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        pagination: {
            el: ".swiper-pagination",
        },
        breakpoints: {
            640: {
                slidesPerView: 4,
                spaceBetween: 10,
            },
            768: {
                slidesPerView: 5,
                spaceBetween: 15,
            },
            1024: {
                slidesPerView: 5.5,
                spaceBetween: 0,
            },
        },
    });
    // hide show up arrow
    if (up) {
        window.addEventListener("scroll", () => {
            console.log(window.scrollY);
            console.log(window.scrollY < 200);
            if (window.scrollY < 200) {
                up.classList.add("hidden");
                up.classList.remove("block");

            } else {
                up.classList.add("block");
                up.classList.remove("hidden");
            }
            if (window.screen.width < 768) {
                if (window.scrollY > 7530) {
                    up.classList.add("hidden");
                    whatsapp.classList.add("hidden")
                } else {
                    if (window.scrollY < 200) {
                        up.classList.add("hidden");
                        up.classList.remove("block");

                    } else {
                        up.classList.remove("hidden");
                        whatsapp.classList.remove("hidden")
                    }
                }

            }
        })
    }

    // bars
    bars.addEventListener("click", (e) => {
        e.preventDefault();
        mainheader.classList.add("right-0");
        mainheader.classList.remove("right-100/100");
        let black = document.createElement("div");
        black.id = black;
        black.classList.add("fixed", "top-0", "right-0", "w-full", "h-screen", "z-4", "backdrop-blur-3xl");
        body.append(black);
        black.addEventListener("click", () => {
            mainheader.classList.remove("right-0");
            mainheader.classList.add("right-100/100");
            black.remove();
        })
    })

});